package dk.tec.seb;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AnalyzeRequest {
	private MatchEnum level;
	private int id;

	public MatchEnum getLevel() {
		return level;
	}

	public int getId() {
		return id;
	}

	public AnalyzeRequest(String pathInfo) 
	{
		Matcher matcher;
		
		if ((matcher = Pattern.compile("/Person/([0-9]+)").matcher(pathInfo)).find()) {
            level = MatchEnum.MatchPersonId;
            id = Integer.parseInt(matcher.group(1));
        } else if (Pattern.compile("/Person").matcher(pathInfo).find()) {
            level = MatchEnum.MatchPerson;
        } else if ((matcher = Pattern.compile("/HairCorlor/([0-9]+)").matcher(pathInfo)).find()) {
            level = MatchEnum.MatchHairCorlorId;
            id = Integer.parseInt(matcher.group(1));
        } else if (Pattern.compile("/HairCorlor").matcher(pathInfo).find()) {
            level = MatchEnum.MatchHairCorlor;
        } else if ((matcher = Pattern.compile("/ProgramingId/([0-9]+)").matcher(pathInfo)).find()) {        	
            level = MatchEnum.MatchProgramingId;
            id = Integer.parseInt(matcher.group(1));
        } else if (Pattern.compile("/ProgramingLanguage").matcher(pathInfo).find()) {
            level = MatchEnum.MatchProgramingLanguage;
        } else {
            level = MatchEnum.MatchNo;
        }
	}
}
