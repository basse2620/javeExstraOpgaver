package com.example.multiplecalculators;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnZero, btnOne, btnTwo, btnThree, btnFour, btnFive, btnSix, btnSeven, btnEight,
            btnNine, btnAdd, btnSubtract, btnMultiply, btnDivide, btnProcent, btnEqual, btnReturn,
            btnC, btnPN, namePageBtn, btnComma;

    EditText firstNameTxt, lastNameTxt;

    TextView txtTypeField, namePageResultTxt, resultTextTxt;

    Intent theIntent;

    ActivityResultLauncher<Intent> secondCalculatorActivityLauncher;
    ActivityResultLauncher<Intent> nameActivityLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnZero = findViewById(R.id.btnZero);
        btnOne =  findViewById(R.id.btnOne);
        btnTwo = findViewById(R.id.btnTwo);
        btnThree = findViewById(R.id.btnThree);
        btnFour = findViewById(R.id.btnFour);
        btnFive = findViewById(R.id.btnFive);
        btnSix = findViewById(R.id.btnSix);
        btnSeven = findViewById(R.id.btnSeven);
        btnEight = findViewById(R.id.btnEight);
        btnNine = findViewById(R.id.btnNine);
        btnAdd = findViewById(R.id.btnAdd);
        btnSubtract = findViewById(R.id.btnSubtract);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnDivide = findViewById(R.id.btnDivide);
        btnProcent = findViewById(R.id.btnProcent);
        btnEqual = findViewById(R.id.btnEqual);
        btnReturn = findViewById(R.id.btnReturn);
        btnC = findViewById(R.id.btnC);
        btnPN = findViewById(R.id.btnPN);
        btnComma = findViewById(R.id.btnComma);
        namePageBtn = findViewById(R.id.namePageBtn);
        txtTypeField = findViewById(R.id.txtTypeField);
        firstNameTxt = findViewById(R.id.firstNameTxt);
        lastNameTxt = findViewById(R.id.lastNameTxt);
        resultTextTxt = findViewById(R.id.resultTextTxt);
        namePageResultTxt = findViewById(R.id.namePageResultTxt);

        btnZero.setOnClickListener(this);
        btnOne.setOnClickListener(this);
        btnTwo.setOnClickListener(this);
        btnThree.setOnClickListener(this);
        btnFour.setOnClickListener(this);
        btnFive.setOnClickListener(this);
        btnSix.setOnClickListener(this);
        btnSeven.setOnClickListener(this);
        btnEight.setOnClickListener(this);
        btnNine.setOnClickListener(this);
        btnAdd.setOnClickListener(this);
        btnSubtract.setOnClickListener(this);
        btnMultiply.setOnClickListener(this);
        btnDivide.setOnClickListener(this);
        btnProcent.setOnClickListener(this);
        btnReturn.setOnClickListener(this);
        btnC.setOnClickListener(this);
        btnPN.setOnClickListener(this);
        btnEqual.setOnClickListener(this);
        btnComma.setOnClickListener(this);
        namePageBtn.setOnClickListener(this);

        secondCalculatorActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK)
                        {
                            Intent intent = result.getData();
                            String resultStr = intent.getStringExtra("resultFromSecondCalc");
                            txtTypeField.setText(resultStr);
                        }
                    }
                }
        );

        nameActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK)
                        {
                            Intent intent = result.getData();
                            String resultStr = intent.getStringExtra("nameLength");
                            String btnClickedStr = intent.getStringExtra("btnClick");
//                            Log.v("Tag",btnClickedStr);
                            namePageResultTxt.setText(resultStr);
                            resultTextTxt.setText(btnClickedStr);
                        }
                    }
                }
        );
    }

    @Override
    public void onClick(View v) {
        if (v == namePageBtn)
        {
            theIntent = new Intent(this, NameActivity.class);
            String firstNameStr = firstNameTxt.getText().toString();
            String lastNameStr = lastNameTxt.getText().toString();
            theIntent.putExtra("firstNameToNamePage", firstNameStr);
            theIntent.putExtra("lastNameToNamePage", lastNameStr);
            nameActivityLauncher.launch(theIntent);
        }
        else
        {
        String imput = txtTypeField.getText().toString();
        String result = "";
        String[] strArray;
        switch (v.getId()) {
            case R.id.btnZero:
                imput = imput + "0";
                break;
            case R.id.btnOne:
                imput = imput + "1";
                break;
            case R.id.btnTwo:
                imput = imput + "2";
                break;
            case R.id.btnThree:
                imput = imput + "3";
                break;
            case R.id.btnFour:
                imput = imput + "4";
                break;
            case R.id.btnFive:
                imput = imput + "5";
                break;
            case R.id.btnSix:
                imput = imput + "6";
                break;
            case R.id.btnSeven:
                imput = imput + "7";
                break;
            case R.id.btnEight:
                imput = imput + "8";
                break;
            case R.id.btnNine:
                imput = imput + "9";
                break;
            case R.id.btnAdd:
                imput = imput + " + ";
                break;
            case R.id.btnSubtract:
                imput = imput + " - ";
                break;
            case R.id.btnMultiply:
                imput = imput + " * ";
                break;
            case R.id.btnDivide:
                imput = imput + " / ";
                break;
            case R.id.btnProcent:
                imput = imput + " % ";
                break;
            case R.id.btnReturn:
                theIntent = new Intent(this, SecondCalculatorActivity.class);
                String str = txtTypeField.getText().toString();
                theIntent.putExtra("resultToSecond", str);
                secondCalculatorActivityLauncher.launch(theIntent);
                break;
            case R.id.btnC:
                imput = "";
                break;
            case R.id.btnPN:
                strArray = imput.split("\\s");
                if (strArray.length == 1)
                {
                    double firstNumber = Double.parseDouble(strArray[0]);
                    if (strArray[0].contains("-"))
                    {
                        imput = String.valueOf(firstNumber * -1);
                    }
                    else
                    {
                        imput = "-" + imput;
                    }
                }
                else if (strArray.length == 2)
                {
                    imput = imput + "-";
                }
                else if (strArray.length == 3)
                {
                    double secondNumber = Double.parseDouble(strArray[2]);
                    if (strArray[2].contains("-"))
                    {
                        imput = strArray[0] + " " + strArray[1] + " " + String.valueOf(secondNumber * -1);
                    }
                    else
                    {
                        imput = strArray[0] + " " + strArray[1] + " -" + strArray[2];
                    }
                }
                break;
            case R.id.btnComma:
                if (imput.equals(""))
                {
                    imput = "0,";
                }
                else {
                    imput = imput + ",";
                }
                break;
            case R.id.btnEqual:
                strArray = imput.split("\\s");
                double firstNumber = Double.parseDouble(strArray[0]),
                        secondNumber = Double.parseDouble(strArray[2]);
                switch (strArray[1]) {
                    case "+":
                        result = String.valueOf(firstNumber + secondNumber);
                        break;
                    case "-":
                        result = String.valueOf(firstNumber - secondNumber);
                        break;
                    case "*":
                        result = String.valueOf(firstNumber * secondNumber);
                        break;
                    case "/":
                        result = String.valueOf(firstNumber / secondNumber);
                        break;
                    case "%":
                        result = String.valueOf(firstNumber / 100 * secondNumber);
                        break;
                }
                break;
            }
            if (result != "") {
                txtTypeField.setText(result);
            } else {
                txtTypeField.setText(imput);
            }
        }
    }
}