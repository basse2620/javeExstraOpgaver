package dk.tec.seb;

import java.util.Scanner;

public class ThreadMain {
	
	DataKlasse dataK = new DataKlasse();
		
	public static void main(String[] args) {
		ThreadOne t1 = new ThreadOne(dataK);
		
	}
}