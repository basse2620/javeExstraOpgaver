package com.example.calculatormenu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnCalc;
    EditText txtFirstNumber, txtSecondNumber;
    ImageView imgCalcType;
    TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCalc = findViewById(R.id.btnCalc);
        imgCalcType = findViewById(R.id.imgCalcType);
        txtFirstNumber = findViewById(R.id.txtFirstNumber);
        txtSecondNumber = findViewById(R.id.txtSecondNumber);
        txtResult = findViewById(R.id.txtResult);

        btnCalc.setOnClickListener(this);
        imgCalcType.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v == btnCalc)
        {
            Double firstNumber = Double.parseDouble(txtFirstNumber.getText().toString());
            Double secondNumber = Double.parseDouble(txtSecondNumber.getText().toString());
            switch (btnCalc.getText().toString())
            {
                case "Add":
                    txtResult.setText(String.valueOf(firstNumber + secondNumber));
                    break;
                case "Subtract":
                    txtResult.setText(String.valueOf(firstNumber - secondNumber));
                    break;
                case "Multiply":
                    txtResult.setText(String.valueOf(firstNumber * secondNumber));
                    break;
                case "Divide":
                    txtResult.setText(String.valueOf(firstNumber / secondNumber));
                    break;
            }
        }
        else if (v == imgCalcType)
        {
            PopupMenu calcTypePopup = new PopupMenu(this, imgCalcType);
            calcTypePopup.getMenu().add(Menu.NONE, 0, Menu.NONE, "Add");
            calcTypePopup.getMenu().add(Menu.NONE, 1, Menu.NONE, "Subtract");
            calcTypePopup.getMenu().add(Menu.NONE, 2, Menu.NONE, "Multiply");
            calcTypePopup.getMenu().add(Menu.NONE, 3, Menu.NONE, "Divide");

            calcTypePopup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    btnCalc.setText(item.getTitle());
                    return true;
                }
            });
            calcTypePopup.show();
        }
    }


}