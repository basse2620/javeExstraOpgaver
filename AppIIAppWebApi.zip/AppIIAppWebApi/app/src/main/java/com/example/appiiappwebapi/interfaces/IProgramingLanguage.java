package com.example.appiiappwebapi.interfaces;

import com.example.appiiappwebapi.modles.ProgramingLanguage;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface IProgramingLanguage {
    @GET("ProgramingLanguage")
    Call<List<ProgramingLanguage>> getProgramingLanguages();

    @GET("ProgramingId/{hairId}")
    Call<ProgramingLanguage>  getProgramingLanguageById(@Path("hairId") int hairId);
}
