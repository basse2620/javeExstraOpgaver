package dk.tec.seb;

public class DataKlasse {
	String name;
	int counter;
	boolean flag = true;	
	
	public DataKlasse(String name, int counter, boolean flag) {
		super();
		this.name = name;
		this.counter = counter;
		this.flag = flag;
	}	
	
	public DataKlasse() {}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getCounter() {
		return counter;
	}
	
	public void setCounter(int counter) {
		this.counter = counter;
	}
	
	public boolean isFlag() {
		return flag;
	}
	
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
}
