package com.example.twoactivitys;

import java.io.Serializable;

public class Elev implements Serializable
{
    public int id;
    public String name;
}
