package com.example.appiiappwebapi;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.example.appiiappwebapi.modles.Person;

import java.util.ArrayList;

public class PersonAdapter extends BaseAdapter
{
    private ArrayList<Person> personList;
    private final MainActivity main;

    public PersonAdapter(MainActivity main, ArrayList<Person> personList)
    {
        this.main = main;
        this.personList = personList;
    }
    @Override
    public int getCount() {
        return personList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(main);
        View v = inflater.inflate(R.layout.list_item, null);

        Person person = personList.get(position);

        ImageView imageView = v.findViewById(R.id.imgStar);
        if (person.getFavorite())
        {
            imageView.setImageResource(R.drawable.images);
        }

        return v;
    }
}
