package com.example.custsomizedlist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Balls> balls;
    ListView lstBalls;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        balls = new ArrayList<Balls>();
        balls.add(new Balls("Poké Ball", "A device for catching wild Pokémon. It is thrown like a ball at the target. It is designed as a capsule system.", R.drawable.pokeball));
        balls.add(new Balls("Great Ball", "A good, high-performance Ball that provides a higher Pokémon catch rate than a standard Poké Ball.", R.drawable.greatball));
        balls.add(new Balls("Ultra Ball", "An ultra-performance Ball that provides a higher Pokémon catch rate than a Great Ball.", R.drawable.ultraball));
        balls.add(new Balls("Master Ball", "The best Ball with the ultimate level of performance. It will catch any wild Pokémon without fail.", R.drawable.masterball));
        balls.add(new Balls("Safari Ball", "A special Poké Ball that is used only in the Great Marsh. It is decorated in a camouflage pattern.", R.drawable.safariball));
        balls.add(new Balls("Fast Ball", "A Poké Ball that makes it easier to catch fast Pokémon.", R.drawable.fastball));
        balls.add(new Balls("Level Ball", "A Poké Ball for catching Pokémon that are a lower level than your own.", R.drawable.levelball));
        balls.add(new Balls("Level Ball", "A Poké Ball for catching very heavy Pokémon.", R.drawable.heavyball));
        balls.add(new Balls("Level Ball", "A Poké Ball for catching Pokémon hooked by a Rod when fishing.", R.drawable.lureball));

        BallsAdapter ballsAdapter = new BallsAdapter(this, balls);
        ballsAdapter.notifyDataSetChanged();

        lstBalls = findViewById(R.id.lstBalls);
        lstBalls.setAdapter(ballsAdapter);
    }
}