package com.example.sensorproject;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;

public class MyGraphics extends View implements SensorEventListener, Runnable{
    Drawable ball;
    MainActivity main;
    float x = 200, y = 300;
    float xMove, yMove;
    float screenH, screenW;
    int ballH, ballW;

    public MyGraphics(MainActivity main) {
        super(main);
        this.main = main;
        ball = main.getResources().getDrawable(R.drawable.kugle, null);
        ballH = ball.getIntrinsicHeight() / 7;
        ballW = ball.getIntrinsicWidth() / 7;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        screenH = h;
        screenW = w;
    }

    @Override
    public void draw(@NonNull Canvas canvas) {
        super.draw(canvas);
        ball.setBounds((int)x, (int)y, (int)x + ballW, (int)y + ballH);
        ball.draw(canvas);
    }

    @Override
    public void onSensorChanged(SensorEvent event)
    {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
        {
            main.updataValues(event.values);
            float xSlope = -event.values[0] / 15;
            float ySlope = event.values[1] / 15;
            xMove += xSlope * 0.8f;
            yMove += ySlope * 0.8f;

            if ((y + ballH) >= screenH)
            {
                yMove = -Math.abs(yMove) * 0.8f;
            }
            else if (y <= 0)
            {
                yMove = Math.abs(yMove) * 0.8f;
            }
            if ((x + ballW) >= screenW)
            {
                xMove = -Math.abs(xMove) * 0.8f;
            }
            else if (x <= 0)
            {
                xMove = Math.abs(xMove) * 0.8f;
            }

            x += xMove;
            y += yMove;

            invalidate();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void run() {
        while (true)
        {
//            if ((y + ballH) >= screenH)
//            {
//                yMove = 0;
//            }
//            else if (y <= 0)
//            {
//                yMove = 0;
//            }
//            if ((x + ballW) >= screenW)
//            {
//                xMove = 0;
//            }
//            else if (x <= 0)
//            {
//                xMove = 0;
//            }

            x += xMove;
            y += yMove;
            Log.d("tag", x + " " + y);
            postInvalidate();
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
