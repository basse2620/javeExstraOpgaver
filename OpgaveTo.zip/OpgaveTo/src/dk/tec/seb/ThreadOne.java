package dk.tec.seb;

public class ThreadOne {

}
