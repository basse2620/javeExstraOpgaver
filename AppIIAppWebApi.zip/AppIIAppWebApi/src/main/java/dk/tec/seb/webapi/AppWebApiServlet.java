package dk.tec.seb.webapi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.ObjectMapper;

import dk.tec.seb.AnalyzeRequest;
import dk.tec.seb.DBTools;
import dk.tec.seb.HairCorlor;
import dk.tec.seb.Person;
import dk.tec.seb.ProgramingLanguage;

/**
 * Servlet implementation class AppWebApiServlet
 */
@WebServlet("/AppWebApiServlet")
public class AppWebApiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AppWebApiServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String json;
		
		PrintWriter out = response.getWriter();
		
		AnalyzeRequest analyze = new AnalyzeRequest(request.getPathInfo());
		
		ObjectMapper mapper = new ObjectMapper();
		
		DBTools db = new DBTools();
		
		Connection con;
		
		switch(analyze.getLevel())
		{
		case MatchPersonId:
			Person p = db.getPersonById(analyze.getId());
			json = mapper.writeValueAsString(p);
			out.write(json);
			break;
		case MatchPerson:
			ArrayList<Person> pL = db.getPerson();
			json = mapper.writeValueAsString(pL);
			out.write(json);
			break;
		case MatchHairCorlorId:
			HairCorlor h = db.getHairCorlorById(analyze.getId());
			json = mapper.writeValueAsString(h);
			out.write(json);
			break;
		case MatchHairCorlor:
			ArrayList<HairCorlor> hL = db.getHairCorlor();
			json = mapper.writeValueAsString(hL);
			out.write(json);
			break;
		case MatchProgramingId:
			ProgramingLanguage pg = db.getProgramingLanguageById(analyze.getId());
			json = mapper.writeValueAsString(pg);
			out.write(json);
			break;
		case MatchProgramingLanguage:
			ArrayList<ProgramingLanguage> pgL = db.getProgramingLanguage();
			json = mapper.writeValueAsString(pgL);
			out.write(json);
			break;
		case MatchNo:
			out.print("{}");
			break;
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        String str = reader.readLine();
        System.out.println(str);
        ObjectMapper mapper = new ObjectMapper();
        Person person = mapper.readValue(str, Person.class);
        DBTools db = new DBTools();
        int id = db.createPerson(person);

        System.out.println(id);

        PrintWriter out = response.getWriter();
        String json = mapper.writeValueAsString(person);
        out.print("bruger oprettet med id: " + id);

    }
	
protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {        
        AnalyzeRequest analyze = new AnalyzeRequest(request.getPathInfo());
        PrintWriter out = response.getWriter();
        DBTools db = new DBTools();
        switch (analyze.getLevel()) {
            case MatchPersonId:
                System.out.println("MatchPersonId");
                Boolean b = db.deletePerson(analyze.getId());
                out.print("user with id " + analyze.getId() + " deleted: " + b);
                break;
        }
    }

protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	PrintWriter out = response.getWriter();
        BufferedReader reader = request.getReader();
        String str = reader.readLine();
        System.out.println(str);
        ObjectMapper mapper = new ObjectMapper();
        Person person = mapper.readValue(str, Person.class);
        DBTools db = new DBTools();
        int id = db.updatePerson(person);

        System.out.println(id);

        String json = mapper.writeValueAsString(person);
        out.print("bruger med id: " + id + " opdateret");

    }

}
