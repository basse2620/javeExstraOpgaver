package com.example.appiiappwebapi.interfaces;

import com.example.appiiappwebapi.modles.HairCorlor;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface IHairCorlorService {
    @GET("HairCorlor")
    Call<List<HairCorlor>> getPersons();

    @GET("HairCorlor/{hairId}")
    Call<HairCorlor>  getPersonById(@Path("hairId") int hairId);
}
