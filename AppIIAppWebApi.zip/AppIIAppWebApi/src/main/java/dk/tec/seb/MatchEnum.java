package dk.tec.seb;

public enum MatchEnum {
	MatchPersonId, MatchPerson, MatchHairCorlorId, MatchHairCorlor, MatchProgramingId, MatchProgramingLanguage, MatchNo
}
