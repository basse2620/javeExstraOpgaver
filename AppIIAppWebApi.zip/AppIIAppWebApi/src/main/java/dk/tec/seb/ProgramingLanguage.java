package dk.tec.seb;

public class ProgramingLanguage {
	int programId;
	String name;
	
	public ProgramingLanguage(int programId, String name) {
		super();
		this.programId = programId;
		this.name = name;
	}

	public ProgramingLanguage() {}

	public int getProgramId() {
		return programId;
	}

	public void setProgramId(int id) {
		this.programId = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}	
}
