package dk.tec.seb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DBTools {
	private String conStr = "jdbc:sqlserver://localhost:1433;databaseName=AppIIAppWebApiDb;encrypt=true;trustServerCertificate= true;";
	Connection con;
	Statement stmt;

	public DBTools() {
		try 
		{
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			System.out.print("Driver Loaded");
		} 
		catch (ClassNotFoundException e) 
		{

			System.out.println("Class not found Exception!!! " + e.getMessage());
		}
	}

	private void connect() 
	{
		try 
		{
			con = DriverManager.getConnection(conStr, "sa", "Passw0rd");
			stmt = con.createStatement();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}

	public Person getPersonById(int id) 
	{
		connect();
		String sqlStr = "Select * from [AppIIAppWebApiDb].[dbo].[Person] where [personId] = " + id;

		Person person = new Person();

		try 
		{
			ResultSet result = stmt.executeQuery(sqlStr);
			if (result.next()) {
				person.setPersonId(result.getInt("personId"));
				person.setName(result.getString("name"));
				person.setPhone(result.getInt("phone"));
				person.setAddress(result.getString("address"));
				person.setNote(result.getString("address"));
				person.setFavorite(result.getBoolean("favorite"));
				person.setHairId(result.getInt("hairId"));
				person.setProgramingId(result.getInt("programingId"));
			}

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}

		return person;
	}

	public ArrayList<Person> getPerson() {
	    connect();
	    String sqlStr = "Select * from [AppIIAppWebApiDb].[dbo].[Person]";

	    ArrayList<Person> persons = new ArrayList<>();

	    try {
	        ResultSet result = stmt.executeQuery(sqlStr);
	        while (result.next()) {
	            Person person = new Person();
	            person.setPersonId(result.getInt("personId"));
	            person.setName(result.getString("name"));
	            person.setPhone(result.getInt("phone"));
	            person.setAddress(result.getString("address"));
	            person.setNote(result.getString("note"));
	            person.setFavorite(result.getBoolean("favorite"));
	            person.setHairId(result.getInt("hairId"));
	            person.setProgramingId(result.getInt("programingId"));
	            persons.add(person);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return persons;
	}
	
	public Boolean deletePerson(int id)
	{
		connect();
		String sqlStr = "Delete From [AppIIAppWebApiDb].[dbo].[Person] Where [personId] = " + id;
		
		try
		{
			int result = stmt.executeUpdate(sqlStr);
			if (result > 0)
			{
				return true;
			}
			else
			{
				return false;
			}			
		}
		catch (SQLException e)
		{
			 e.printStackTrace();
	         return false;
		}
	}
	
	public int createPerson(Person person) {
        connect();
        String fav;
        if (person.getFavorite()) 
        {
        	fav = "1";
        }
        else 
        {
        	fav = "0";
        }
        
        String sqlStr = "INSERT INTO [AppIIAppWebApiDb].[dbo].[Person] VALUES ('" 
        + person.name + "', " + person.getPhone() + ", '" + person.getAddress() 
        + "', '" + person.getNote() + "', " + fav + ", " + person.getHairId() + ", " 
        + person.getProgramingId() + ")";
        
        try {
            System.out.println(sqlStr);
            int result = stmt.executeUpdate(sqlStr);
            if (result > 0) 
            {
                String sqlStr2 = "SELECT [personId] FROM [AppIIAppWebApiDb].[dbo].[Person] WHERE name = '" + person.getName() + "'";
                ResultSet result2 = stmt.executeQuery(sqlStr2);
                if (result2.next()) 
                {
                    return result2.getInt("personId");
                }
            }
            else 
            {
            	return -1;
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
            return -1;
        }
        return -1;
    }
	
	public int updatePerson(Person person) {
        connect();
        String fav;
        if (person.getFavorite()) 
        {
        	fav = "1";        	
        }
        else 
        {
        	fav = "0";
        }
        
        String sqlStr = "UPDATE Person Set name= '" + person.getName() + "', phone=" 
        		+ person.getPhone() + ", address='" + person.getAddress() + "', note='" 
        		+ person.getNote() + "', favorite=" + fav + ", hairId=" + person.getHairId() 
        		+ ", programingId=" + person.getProgramingId()+" WHERE personId = " + person.getPersonId();
        
        try {
            System.out.println(sqlStr);
            int result = stmt.executeUpdate(sqlStr);
            if (result > 0) {
                String sqlStr2 = "SELECT [personId] FROM [AppIIAppWebApiDb].[dbo].[Person] WHERE name = '" + person.getName() +"'";
                ResultSet result2 = stmt.executeQuery(sqlStr2);
                if (result2.next()) {
                    return result2.getInt("personId");
                }
            }
            else return -1;
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
        return -1;
    }

	public HairCorlor getHairCorlorById(int id) 
	{
		connect();
		String sqlStr = "Select * from [AppIIAppWebApiDb].[dbo].[HairCorlor] where [hairId] = " + id;

		HairCorlor hairCorlor = new HairCorlor();

		try 
		{
			ResultSet result = stmt.executeQuery(sqlStr);
			if (result.next()) 
			{
				hairCorlor.setHairId(result.getInt("hairId"));
				hairCorlor.setName(result.getString("name"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return hairCorlor;
	}
	
	public ArrayList<HairCorlor> getHairCorlor() 
	{
		connect();
		String sqlStr = "Select * from [AppIIAppWebApiDb].[dbo].[HairCorlor]";
		
		ArrayList<HairCorlor> hairCorlors = new ArrayList<>();
		

		try 
		{
			ResultSet result = stmt.executeQuery(sqlStr);
			while (result.next()) 
			{
				HairCorlor hairCorlor = new HairCorlor();
				hairCorlor.setHairId(result.getInt("hairId"));
				hairCorlor.setName(result.getString("name"));
				hairCorlors.add(hairCorlor);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return hairCorlors;
	}
	
	public ProgramingLanguage getProgramingLanguageById(int id) 
	{
		connect();
		String sqlStr = "Select * from [AppIIAppWebApiDb].[dbo].[ProgramingLanguage] where programId = " + id;

		ProgramingLanguage programingLanguage = new ProgramingLanguage();

		try 
		{
			ResultSet result = stmt.executeQuery(sqlStr);
			while (result.next()) 
			{
				programingLanguage.setProgramId(result.getInt("programId"));
				programingLanguage.setName(result.getString("name"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return programingLanguage;
	}
	
	public ArrayList<ProgramingLanguage> getProgramingLanguage() 
	{
		connect();
		String sqlStr = "Select * from [AppIIAppWebApiDb].[dbo].[ProgramingLanguage]";
		
		ArrayList<ProgramingLanguage> programingLanguages = new ArrayList<>();
		

		try 
		{
			ResultSet result = stmt.executeQuery(sqlStr);
			while (result.next()) 
			{
				ProgramingLanguage programingLanguage = new ProgramingLanguage();
				programingLanguage.setProgramId(result.getInt("programId"));
				programingLanguage.setName(result.getString("name"));
				programingLanguages.add(programingLanguage);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return programingLanguages;
	}

}
