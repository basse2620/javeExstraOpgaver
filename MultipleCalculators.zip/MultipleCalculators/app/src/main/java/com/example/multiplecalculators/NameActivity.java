package com.example.multiplecalculators;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NameActivity extends AppCompatActivity implements View.OnClickListener {

    Button firstNameBtn, lastNameBtn, fullNameBtn;
    EditText txtFirstName, txtLastName;

    Intent theIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name);

        firstNameBtn = findViewById(R.id.firstNameBtn);
        lastNameBtn = findViewById(R.id.lastNameBtn);
        fullNameBtn = findViewById(R.id.fullNameBtn);
        txtFirstName = findViewById(R.id.txtFirstName);
        txtLastName = findViewById(R.id.txtLastName);

        firstNameBtn.setOnClickListener(this);
        lastNameBtn.setOnClickListener(this);
        fullNameBtn.setOnClickListener(this);

        theIntent = getIntent();
        String firstNameStr = theIntent.getStringExtra("firstNameToNamePage"),
                lastNameStr = theIntent.getStringExtra("lastNameToNamePage");
        txtFirstName.setText(firstNameStr);
        txtLastName.setText(lastNameStr);

    }

    @Override
    public void onClick(View v) {
        String firstNameStr = txtFirstName.getText().toString(),
                lastNameStr = txtLastName.getText().toString(),
                fullNameStr = firstNameStr + lastNameStr, nameLength = "", btnClick= "";

        if (v == firstNameBtn)
        {
            nameLength = String.valueOf(firstNameStr.length());
            btnClick = "The length of the first name is:";
        }
        else if (v == lastNameBtn)
        {
            nameLength = String.valueOf(lastNameStr.length());
            btnClick = "The length of the last name is:";

        }
        else if (v == fullNameBtn)
        {
            nameLength = String.valueOf(fullNameStr.length());
            btnClick = "The length of the full name is:";

        }
        theIntent.putExtra("nameLength", nameLength);
        theIntent.putExtra("btnClick", btnClick);
        setResult(NameActivity.RESULT_OK, theIntent);
        finish();
    }
}