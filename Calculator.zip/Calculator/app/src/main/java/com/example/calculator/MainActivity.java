package com.example.calculator;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button plusBtn, minusBtn,multipliBtn, divideBtn, caclBtn, rdgCalcBtn, btnSwitchToSecond;
    EditText firstNumberTxt;
    EditText secondNumberTxt;
    EditText resultTxt;
    Spinner operatorSpinner;
    RadioGroup rdgCalcType;

    String[] test = {"Add", "Subtract", "Multiply", "Divide"};

    ActivityResultLauncher<Intent> secondActivityLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        plusBtn = findViewById(R.id.plusBtn);
        minusBtn = findViewById(R.id.minusBtn);
        multipliBtn = findViewById(R.id.multipliBtn);
        divideBtn = findViewById(R.id.divideBtn);
        firstNumberTxt = findViewById(R.id.firstNumberTxt);
        secondNumberTxt = findViewById(R.id.secondNumberTxt);
        resultTxt = findViewById(R.id.resultTxt);
        operatorSpinner = findViewById(R.id.operatorSpinner);
        caclBtn = findViewById(R.id.calcBtn);
        rdgCalcType = findViewById(R.id.rdgCalcType);
        rdgCalcBtn = findViewById(R.id.rdgCalcBtn);
        btnSwitchToSecond = findViewById(R.id.btnSwitchToSecond);

        ArrayAdapter adapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_item,
                test);

        rdgCalcBtn.setOnClickListener(this);

        btnSwitchToSecond.setOnClickListener(this);
        operatorSpinner.setAdapter(adapter);
        plusBtn.setOnClickListener(this);
        minusBtn.setOnClickListener(this);
        multipliBtn.setOnClickListener(this);
        divideBtn.setOnClickListener(this);
        caclBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int firstNumber = Integer.parseInt(firstNumberTxt.getText().toString());
                int secondNumber = Integer.parseInt((secondNumberTxt.getText().toString()));
                String selectedOperator = operatorSpinner.getSelectedItem().toString();
                switch (selectedOperator) {
                    case "Add":
                        resultTxt.setText(String.valueOf(firstNumber + secondNumber));
                        break;
                    case "Subtract":
                        resultTxt.setText(String.valueOf(firstNumber - secondNumber));
                        break;
                    case "Multiply":
                        resultTxt.setText(String.valueOf(firstNumber * secondNumber));
                        break;
                    case "Divide":
                        if (secondNumber != 0) {
                            resultTxt.setText(String.valueOf(firstNumber / secondNumber));
                        } else {
                            resultTxt.setText("Cannot divide by zero.");
                            return;
                        }
                        break;
                }

            }
        });

        secondActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK)
                        {
//                            Intent intent = result.getData();
//                            int resultInt = intent.getIntExtra("resultIntFromSecond", 0);
//                            resultTxt.setText(String.valueOf(resultInt));
                        }
                    }
                }
        );

//        plusBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//            int firstNumber = Integer.parseInt(firstNumberTxt.getText().toString());
//            int secondNumber = Integer.parseInt((secondNumberTxt.getText().toString()));
//                resultTxt.setText(String.valueOf(firstNumber + secondNumber));
//            }
//        });
//        minusBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                int firstNumber = Integer.parseInt(firstNumberTxt.getText().toString());
//                int secondNumber = Integer.parseInt((secondNumberTxt.getText().toString()));
//                resultTxt.setText(String.valueOf(firstNumber - secondNumber));
//            }
//        });
//        multipliBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                int firstNumber = Integer.parseInt(firstNumberTxt.getText().toString());
//                int secondNumber = Integer.parseInt((secondNumberTxt.getText().toString()));
//                resultTxt.setText(String.valueOf(firstNumber * secondNumber));
//            }
//        });
//        divideBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                int firstNumber = Integer.parseInt(firstNumberTxt.getText().toString());
//                int secondNumber = Integer.parseInt((secondNumberTxt.getText().toString()));
//                resultTxt.setText(String.valueOf(firstNumber / secondNumber));
//            }
//        });
    }

    @Override
    public void onClick(View v) {
        int firstNumber = Integer.parseInt(firstNumberTxt.getText().toString());
        int secondNumber = Integer.parseInt((secondNumberTxt.getText().toString()));

/*        if(v.getId() == R.id.plusBtn)
        {
            resultTxt.setText(String.valueOf(firstNumber + secondNumber));
        }
        else if(v.getId() == R.id.minusBtn)
        {
            resultTxt.setText(String.valueOf(firstNumber - secondNumber));
        }
        else if(v.getId() == R.id.multipliBtn)
        {
            resultTxt.setText(String.valueOf(firstNumber * secondNumber));
        }
        else if(v.getId() == R.id.divideBtn)
        {
            resultTxt.setText(String.valueOf(firstNumber / secondNumber));
        }*/
        switch (v.getId()) {
            case R.id.btnSwitchToSecond:
                int re = firstNumber + secondNumber;
                Intent intent = new Intent(this, SecondActivity.class);
                intent.putExtra("firstNumber", firstNumber);
                intent.putExtra("Result", re);
                secondActivityLauncher.launch(intent);
                break;
            case R.id.rdgCalcBtn:

                break;
            case R.id.plusBtn:
                resultTxt.setText(String.valueOf(firstNumber + secondNumber));
                break;
            case R.id.minusBtn:
                resultTxt.setText(String.valueOf(firstNumber - secondNumber));
                break;
            case R.id.multipliBtn:
                resultTxt.setText(String.valueOf(firstNumber * secondNumber));
                break;
            case R.id.divideBtn:
                resultTxt.setText(String.valueOf(firstNumber / secondNumber));
                break;
            default:
                resultTxt.setText(String.valueOf(v.getId()));
                break;
        }
    }
}