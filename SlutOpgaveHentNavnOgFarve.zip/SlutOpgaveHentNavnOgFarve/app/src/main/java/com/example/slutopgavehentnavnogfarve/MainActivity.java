package com.example.slutopgavehentnavnogfarve;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button colorBtn, nameBtn;
    TextView resultTxt;

    Intent theIntent;

    ActivityResultLauncher<Intent> ColorActivityLauncher;
    ActivityResultLauncher<Intent> NameActivityLauncher;

    String nameStr = "", typeStr = "", colorStr = "#000000";
    String[] setColors = {"00", "00", "00"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        colorBtn = findViewById(R.id.colorBtn);
        nameBtn = findViewById(R.id.nameBtn);
        resultTxt = findViewById(R.id.resultTxt);

        colorBtn.setOnClickListener(this);
        nameBtn.setOnClickListener(this);

        ColorActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK)
                        {
                            Intent intent = result.getData();
                            colorStr = intent.getStringExtra("colorStr");
                            setColors = intent.getStringArrayExtra("setColors");
                            if (colorStr.equals("#000000"))
                            {
                                resultTxt.setTextColor(Color.parseColor("#FFFFFF"));
                            }
                            resultTxt.setBackgroundColor(Color.parseColor(colorStr));
                        }
                    }
                }
        );

        NameActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK)
                        {
                            Intent intent = result.getData();
                            nameStr = intent.getStringExtra("nameStr");
                            typeStr = intent.getStringExtra("typeStr");
                            resultTxt.setText(typeStr + "'s Name: " + nameStr);
                        }
                    }
                }
        );
    }

    @Override
    public void onClick(View v) {
        if (v == colorBtn)
        {
            theIntent = new Intent(this, GetColorActivity.class);
            theIntent.putExtra("nameStr", nameStr);
            theIntent.putExtra("typeStr", typeStr);
            theIntent.putExtra("colorStr", colorStr);
            theIntent.putExtra("setColors", setColors);
            ColorActivityLauncher.launch(theIntent);
        }
        else if (v == nameBtn)
        {
            theIntent = new Intent(this, GetNameActivity.class);
            theIntent.putExtra("nameStr", nameStr);
            theIntent.putExtra("typeStr", typeStr);
            NameActivityLauncher.launch(theIntent);
        }
    }
}