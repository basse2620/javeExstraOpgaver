package com.example.twoactivitys;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    Button btnGoToSecond;
    TextView txtFromSecond;
    EditText txtToSecond;
    Intent theIntent;

    public static final String TEXT_TO_MAIN = "TextToMain";
    public static final String TEXT_FROM_MAIN = "TextFromMain";
    ActivityResultLauncher<Intent> secondActivityLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtFromSecond = findViewById(R.id.txtFromSecond);
        txtToSecond = findViewById(R.id.txtToSecond);
        btnGoToSecond = findViewById(R.id.btnGoToSecond);

        btnGoToSecond.setOnClickListener(this);

        theIntent = getIntent();
        String str = theIntent.getStringExtra("strFromMain");
        txtFromSecond.setText(str);
//        txtFromSecond.setText(String.valueOf(theIntent.getStringExtra("strFromSecond")));

        secondActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK)
                        {
                            Intent intent = result.getData();
                            String str = intent.getStringExtra(TEXT_TO_MAIN);
                            Log.v("Tag", str);
                            txtFromSecond.setText(str);
                        }
                    }
                }
        );
    }

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent(this, SecondActivity.class);
        String str = txtToSecond.getText().toString();
        intent.putExtra(TEXT_FROM_MAIN, str);
        intent.putExtra("TAL", 5);
        Elev e = new Elev();
        e.name = "Jan";
        intent.putExtra("Elev", e);
//        startActivity(intent);
//        ((Button)v).setText("Der blev trykket på mig");
//        if(v == btnGoToSecond) {}
//        if(v.getId() == R.id.btnGoToSecond) {}

        secondActivityLauncher.launch(intent);
    }
}