package com.example.appiiappwebapi;

import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.appiiappwebapi.interfaces.IPersonService;
import com.example.appiiappwebapi.modles.Person;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PersonAdapter extends BaseAdapter {
    private ArrayList<Person> personList;
    private final MainActivity main;


    public PersonAdapter(MainActivity main, ArrayList<Person> personList)
    {
        this.main = main;
        this.personList = personList;
    }
    @Override
    public int getCount() {
        return personList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(main);
        View v = inflater.inflate(R.layout.list_item, null);

        Person person = personList.get(position);

        ImageView imageView = v.findViewById(R.id.imgStar);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                person.setFavorite(!person.getFavorite());
                updatePerson(person);
            }
        });
        if (person.getFavorite())
        {
            imageView.setImageResource(R.drawable.images);
        }

        TextView txtName = v.findViewById(R.id.txtName);
        TextView txtPhone = v.findViewById(R.id.txtPhone);
        TextView txtNote = v.findViewById(R.id.txtNote);

        txtName.setText(person.getName());
        txtPhone.setText(String.valueOf(person.getPhone()));
        txtNote.setText(person.getNote());
        LinearLayout lstItm = v.findViewById(R.id.lstItm);
        if (position % 2 == 0)
        {
            lstItm.setBackgroundColor(Color.parseColor("#FF0000"));
        }
        else
        {
            lstItm.setBackgroundColor(Color.parseColor("#000000"));
        }


        return v;
    }

    public void updatePerson(Person person)
    {
        IPersonService service = ServiceBuilder.bulderService(IPersonService.class);
        Call<Integer> updateCall = service.updatePerson(person);
        updateCall.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
            }

            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                Log.d("debug", "t");
            }
        });
        notifyDataSetChanged();
    }
}
