package com.example.custsomizedlist;

import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import java.util.ArrayList;

public class BallsAdapter extends BaseAdapter {
    private final ArrayList<Balls> balls;
    private final MainActivity main;

    public BallsAdapter(MainActivity main, ArrayList<Balls> balls) {
        this.balls = balls;
        this.main = main;
    }

    @Override
    public int getCount() {
        return balls.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(main);
        View v = inflater.inflate(R.layout.list_item, null);

        Balls ball = balls.get(position);

        ImageView imgView = v.findViewById(R.id.imgBalls);
        imgView.setImageResource(ball.getPictureId());
        TextView txtName = v.findViewById(R.id.txtName);
        txtName.setText(ball.getName());
        TextView txtDiscrip = v.findViewById(R.id.txtDiscrip);
        txtDiscrip.setText(ball.getDescription());

        Button btnDelete = v.findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                balls.remove(position);
                notifyDataSetChanged();
//                AlertDialog.Builder alert = new AlertDialog.Builder(main);
//                alert.setTitle("Delete Ball?");
//                alert.setMessage("Ønsker De at slette den Kugle?");
//                alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int whichButton) {
//                        int posToRemove = position;
//                        Balls remove = balls.remove(posToRemove);
//                        notifyDataSetChanged();
//                    }
//                });
//                alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int whichButton) {
//                    }
//                });
            }
        });
        return v;
    }
}
