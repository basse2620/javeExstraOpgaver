package com.example.appiiappwebapi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.appiiappwebapi.interfaces.IHairCorlorService;
import com.example.appiiappwebapi.interfaces.IPersonService;
import com.example.appiiappwebapi.interfaces.IProgramingLanguage;
import com.example.appiiappwebapi.modles.HairCorlor;
import com.example.appiiappwebapi.modles.Person;
import com.example.appiiappwebapi.modles.ProgramingLanguage;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener, CompoundButton.OnCheckedChangeListener, RadioGroup.OnCheckedChangeListener {

    ArrayList<HairCorlor> hairCorlors;
    ArrayList<ProgramingLanguage> programs;
    ArrayList<String> color = new ArrayList<>();
    int position;
    Person person;

    Button btnCancel, btnDelete, btnUpdate;
    EditText txtAddress, txtName, txtNote, txtPhone;
    CheckBox chbFavorite;
    RadioGroup rdgProgram;
    Spinner spnHairColor;
    TextView  txtId;

    Intent theIntent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        btnCancel = findViewById(R.id.btnCancel);
        btnDelete = findViewById(R.id.btnDelete);
        btnUpdate = findViewById(R.id.btnUpdate);
        chbFavorite = findViewById(R.id.chbFavorite);
        rdgProgram = findViewById(R.id.rdgProgram);
        spnHairColor = findViewById(R.id.spnHairColor);
        txtAddress = findViewById(R.id.txtAddress);
        txtId = findViewById(R.id.txtId);
        txtName = findViewById(R.id.txtName);
        txtNote = findViewById(R.id.txtNote);
        txtPhone = findViewById(R.id.txtPhone);

        btnCancel.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btnUpdate.setOnClickListener(this);
        chbFavorite.setOnCheckedChangeListener(this);
        rdgProgram.setOnCheckedChangeListener(this);
        spnHairColor.setOnItemSelectedListener(this);

        setTheIntent();
    }

    private void setTheIntent() {
        theIntent = getIntent();
        person = (Person) theIntent.getSerializableExtra("person");
        position = theIntent.getIntExtra("position",0);
        txtId.setText(String.valueOf(person.getPersonId()));
        txtName.setText(person.getName());
        txtPhone.setText(String.valueOf(person.getPhone()));
        txtAddress.setText(person.getAddress());
        txtNote.setText(person.getNote());

        IHairCorlorService service = ServiceBuilder.bulderService(IHairCorlorService.class);
        Call<List<HairCorlor>> hairCorlorCall = service.getHairColor();
        hairCorlorCall.enqueue(new Callback<List<HairCorlor>>() {
            @Override
            public void onResponse(Call<List<HairCorlor>> call, Response<List<HairCorlor>> response) {
                hairCorlors = (ArrayList<HairCorlor>) response.body();
                for (HairCorlor hairCorlor : hairCorlors)
                {
                    color.add(hairCorlor.getName());
                }
                ArrayAdapter adapter = new ArrayAdapter<>(EditActivity.this,
                        android.R.layout.simple_list_item_1,
                        color);
                spnHairColor.setAdapter(adapter);
                int i = 0;
                for (HairCorlor hairCorlor : hairCorlors)
                {
                    if (hairCorlor.getHairId() == person.getHairId())
                    {
                        spnHairColor.setSelection(i);
                    }
                    i++;
                }
                IProgramingLanguage service = ServiceBuilder.bulderService(IProgramingLanguage.class);
                Call<List<ProgramingLanguage>> programingCall = service.getProgramingLanguages();
                programingCall.enqueue(new Callback<List<ProgramingLanguage>>() {
                    @Override
                    public void onResponse(Call<List<ProgramingLanguage>> call, Response<List<ProgramingLanguage>> response) {
                        programs = (ArrayList<ProgramingLanguage>) response.body();
                        for (ProgramingLanguage program : programs)
                        {
                            if (program.getProgramId() == person.getProgramingId())
                            {
                                switch (person.getProgramingId())
                                {
                                    case 1:
                                        rdgProgram.check(R.id.rdbJava);
                                    break;
                                    case 2:
                                        rdgProgram.check(R.id.rdbC);
                                        break;
                                    case 3:
                                        rdgProgram.check(R.id.rdbPython);
                                        break;
                                    case 4:
                                        rdgProgram.check(R.id.rdbJScipt);
                                        break;
                                    case 5:
                                        rdgProgram.check(R.id.rdbFlutter);
                                        break;
                                }
                            }
                        }

                    }
                    @Override
                    public void onFailure(Call<List<ProgramingLanguage>> call, Throwable t) {
                        Log.d("debug", "t");
                    }
                });
            }

            @Override
            public void onFailure(Call<List<HairCorlor>> call, Throwable t) {
                Log.d("debug", "t");
            }
        });
        chbFavorite.setChecked(person.getFavorite());
    }

    @Override
    public void onClick(View v) {
        if (v == btnCancel)
        {
            theIntent.putExtra("type","Canceled");
            setResult(EditActivity.RESULT_OK, theIntent);
            finish();
        }
        else if (v == btnDelete)
        {
            IPersonService service = ServiceBuilder.bulderService(IPersonService.class);
            Call<Void> deleteCall = service.deletePerson(person.getPersonId());
            deleteCall.enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    theIntent.putExtra("type", "Failed to delete person");
                    Log.d("debug", "t");
                }
            });
            theIntent.putExtra("type", "Person Deleted");
            setResult(EditActivity.RESULT_OK, theIntent);
            finish();
        }
        else if (v == btnUpdate)
        {
            person.setName(txtName.getText().toString());
            person.setPhone(Integer.parseInt(txtPhone.getText().toString()));
            person.setAddress(txtAddress.getText().toString());
            person.setNote(txtNote.getText().toString());
            IPersonService service = ServiceBuilder.bulderService(IPersonService.class);
            Call<Integer> updateCall = service.updatePerson(person);
            updateCall.enqueue(new Callback<Integer>() {
                @Override
                public void onResponse(Call<Integer> call, Response<Integer> response) {
                }

                @Override
                public void onFailure(Call<Integer> call, Throwable t) {
                    theIntent.putExtra("type", "Failed to update person");
                    Log.d("debug", "t");
                }
            });
            theIntent.putExtra("type", "Person Updated");
            setResult(EditActivity.RESULT_OK, theIntent);
            finish();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        int i = 0;
        for (HairCorlor color : hairCorlors)
        {
            if (position == i)
            {
                person.setHairId(color.getHairId());
            }
            i++;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        person.setFavorite(isChecked);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId)
        {
            case R.id.rdbJava:
                person.setProgramingId(1);
                break;
            case R.id.rdbC:
                person.setProgramingId(2);
                break;
            case R.id.rdbPython:
                person.setProgramingId(3);
                break;
            case R.id.rdbJScipt:
                person.setProgramingId(4);
                break;
            case R.id.rdbFlutter:
                person.setProgramingId(5);
                break;
        }
    }
}