package com.example.appiiappwebapi.modles;

public class Person {
    int personId;
    String name;
    int phone;
    String address;
    String note;
    Boolean favorite;
    int hairId;
    int programingId;

    public Person(int personId, String name, int phone, String address, String note, Boolean favorite, int hairId, int programingId) {
        super();
        this.personId = personId;
        this.name = name;
        this.phone = phone;
        this.address = address;
        this.note = note;
        this.favorite = favorite;
        this.hairId = hairId;
        this.programingId = programingId;
    }

    public Person() {}

    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int id) {
        this.personId = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Boolean getFavorite() {
        return favorite;
    }

    public void setFavorite(Boolean favorite) {
        this.favorite = favorite;
    }

    public int getHairId() {
        return hairId;
    }

    public void setHairId(int hairId) {
        this.hairId = hairId;
    }

    public int getProgramingId() {
        return programingId;
    }

    public void setProgramingId(int programingId) {
        this.programingId = programingId;
    }
}

