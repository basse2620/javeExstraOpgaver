package com.example.slutopgavehentnavnogfarve;

        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.RadioGroup;
        import android.widget.TextView;

public class GetNameActivity extends AppCompatActivity implements View.OnClickListener, RadioGroup.OnCheckedChangeListener {

    Button sendBtn;
    RadioGroup typeRdg;
    EditText nameTxt;
    TextView nameOfYourTxt;

    Intent theIntent;

    String typeStr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_name);

        sendBtn = findViewById(R.id.sendBtn);
        typeRdg = findViewById(R.id.typeRdg);
        nameTxt = findViewById(R.id.nameTxt);
        nameOfYourTxt = findViewById(R.id.nameOfYourTxt);

        sendBtn.setOnClickListener(this);
        typeRdg.setOnCheckedChangeListener(this);

        setTheIntent();
    }

    public void setTheIntent() {
        theIntent = getIntent();
        typeStr = theIntent.getStringExtra("typeStr");
        String nameStr = theIntent.getStringExtra("nameStr");
        nameTxt.setText(nameStr);
        switch (typeStr)
        {
            case "Mother":
                typeRdg.check(R.id.motherRdb);
                nameOfYourTxt.setText(typeStr + "'s name:");
                break;
            case "Father":
                typeRdg.check(R.id.fatherRdb);
                nameOfYourTxt.setText(typeStr + "'s name:");
                break;
            case "Dog":
                typeRdg.check(R.id.dogRdb);
                nameOfYourTxt.setText(typeStr + "'s name:");
                break;
            case "Cat":
                typeRdg.check(R.id.catRdb);
                nameOfYourTxt.setText(typeStr + "'s name:");
                break;
        }
    }

    @Override
    public void onClick(View v) {
        String nameStr = nameTxt.getText().toString();
        theIntent.putExtra("typeStr", typeStr);
        theIntent.putExtra("nameStr", nameStr);
        setResult(GetNameActivity.RESULT_OK, theIntent);
        finish();
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId)
        {
            case R.id.motherRdb:
                typeStr = "Mother";
                nameOfYourTxt.setText(typeStr + "'s name:");
                break;
            case R.id.fatherRdb:
                typeStr = "Father";
                nameOfYourTxt.setText(typeStr + "'s name:");
                break;
            case R.id.dogRdb:
                typeStr = "Dog";
                nameOfYourTxt.setText(typeStr + "'s name:");
                break;
            case R.id.catRdb:
                typeStr = "Cat";
                nameOfYourTxt.setText(typeStr + "'s name:");
                break;
        }
        Log.v("tag", typeStr);
        Log.v("tag1", String.valueOf(checkedId));
    }
}