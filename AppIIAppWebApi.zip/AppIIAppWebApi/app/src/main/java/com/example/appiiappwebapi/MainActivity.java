package com.example.appiiappwebapi;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;

import com.example.appiiappwebapi.interfaces.IPersonService;
import com.example.appiiappwebapi.modles.Person;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {
    String type;
    PersonAdapter personAdapter;
    ArrayList<Person> personList;
    ListView lstPersons;
    FloatingActionButton fab;
    Intent theIntent;
    ImageView imgStar;

    ActivityResultLauncher<Intent> CreateActivityLauncher;
    ActivityResultLauncher<Intent> EditActivityLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getPersons();

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(this);
        lstPersons = findViewById(R.id.lstPersons);
        lstPersons.setOnItemClickListener(this);


        CreateActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        getPersons();
                        Intent intent = result.getData();
                        type = intent.getStringExtra("type");
                        Log.d("Person122", "onActivityResult: " + type);
                        snBar(type);
                    }
                }
        );

        EditActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        getPersons();
                        Intent intent = result.getData();
                        type = intent.getStringExtra("type");
                        snBar(type);
                    }
                }
        );
    }

    public void getPersons()
    {
        IPersonService iPersonService = ServiceBuilder.bulderService(IPersonService.class);
        Call<List<Person>> lPRequest = iPersonService.getPersons();
        lPRequest.enqueue(new Callback<List<Person>>() {
            @Override
            public void onResponse(Call<List<Person>> call, Response<List<Person>> response) {
                if (response.isSuccessful())
                {
                    personList = (ArrayList<Person>) response.body();
                    personAdapter = new PersonAdapter(MainActivity.this, personList);
                    personAdapter.notifyDataSetChanged();

                    lstPersons = findViewById(R.id.lstPersons);
                    lstPersons.setAdapter(personAdapter);
                }
            }
            @Override
            public void onFailure(Call<List<Person>> call, Throwable t) {
                Log.d("debug", t.toString());
            }
        });
    }

    public void snBar(String str)
    {
        Snackbar snack = Snackbar.make(
                lstPersons,
                "" + str,
                Snackbar.LENGTH_LONG);
        snack.show();
    }

    @Override
    public void onClick(View v) {
        theIntent = new Intent(this, CreateActivity.class);
        CreateActivityLauncher.launch(theIntent);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        theIntent = new Intent(this, EditActivity.class);

        Person person = personList.get(position);
        theIntent.putExtra("position", position);
        theIntent.putExtra("person", person);
        EditActivityLauncher.launch(theIntent);
    }
}