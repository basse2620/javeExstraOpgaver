package com.example.appiiappwebapi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.example.appiiappwebapi.interfaces.IPersonService;
import com.example.appiiappwebapi.modles.Person;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    ArrayList<Person> personList;
    ListView lstPersons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        IPersonService iPersonService = ServiceBuilder.bulderService(IPersonService.class);
        Call<List<Person>> lPRequest = iPersonService.getPersons();
        lPRequest.enqueue(new Callback<List<Person>>() {
            @Override
            public void onResponse(Call<List<Person>> call, Response<List<Person>> response) {
                Log.v("name", "1");
                if (response.isSuccessful())
                {
                    personList = (ArrayList<Person>) response.body();

                }
            }
            @Override
            public void onFailure(Call<List<Person>> call, Throwable t) { }
        });

        PersonAdapter personAdapter = new PersonAdapter(this, personList);
        personAdapter.notifyDataSetChanged();

        lstPersons = findViewById(R.id.lstPersons);
        lstPersons.setAdapter(personAdapter);
    }
}