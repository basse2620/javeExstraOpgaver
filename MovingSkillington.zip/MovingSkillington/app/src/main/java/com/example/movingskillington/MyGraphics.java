package com.example.movingskillington;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;

public class MyGraphics extends View implements Runnable
{
    Drawable skillington;
    MainActivity main;
    int skillingWidth, skillingHeight;
    int x = 200, y = 100;
    int xMove = -1, yMove = 1;
    int screenWidth, screenHeight;
    public MyGraphics(MainActivity main)
    {
        super(main);
        this.main = main;
        skillington = main.getResources().getDrawable(R.drawable.scale, null);
        skillingWidth = skillington.getIntrinsicWidth() / 4;
        skillingHeight = skillington.getIntrinsicHeight() / 3;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        screenWidth = w;
        screenHeight = h;
    }

    @Override
    public void draw(@NonNull Canvas canvas)
    {
        super.draw(canvas);
        skillington.setBounds(x, y, x + skillingWidth, y + skillingHeight);
        skillington.draw(canvas);
    }

    @Override
    public void run()
    {
        while (true)
        {
            x += xMove;
            y += yMove;
            if ((y + skillingHeight) >= screenHeight)
            {
                yMove = yMove * -1;
            }
            else if (y <= 0)
            {
                yMove = yMove * -1;
            }
            if ((x + skillingWidth) >= screenWidth)
            {
                xMove = xMove * -1;
            }
            else if (x <= 0)
            {
                xMove = xMove * -1;
            }

            postInvalidate();
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
