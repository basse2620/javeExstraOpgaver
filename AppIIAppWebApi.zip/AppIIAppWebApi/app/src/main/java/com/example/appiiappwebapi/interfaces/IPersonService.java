package com.example.appiiappwebapi.interfaces;

import com.example.appiiappwebapi.modles.Person;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface IPersonService {

    @GET("Person")
    Call<List<Person>> getPersons();

    @GET("Person/{personId}")
    Call<Person>  getPersonById(@Path("personId") int personId);

    @POST("Person")
    Call<Integer> createPerson(@Body Person person);

    @PUT("Person")
    Call<Integer> updatePerson(@Body Person person);

    @DELETE("Person/{personId}")
    Call<Void> deletePerson(@Path("personId") int personId);

}
