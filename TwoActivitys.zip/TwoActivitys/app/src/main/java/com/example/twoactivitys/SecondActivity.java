package com.example.twoactivitys;

import static com.example.twoactivitys.MainActivity.TEXT_TO_MAIN;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnGoToMain;
    TextView txtFromMain;
    EditText txtToMain;
    Intent theIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        btnGoToMain = findViewById(R.id.btnGoToMain);
        txtToMain = findViewById(R.id.txtToMain);
        txtFromMain = findViewById(R.id.txtFromMain);

        btnGoToMain.setOnClickListener(this);

        theIntent = getIntent();
        String str = theIntent.getStringExtra(MainActivity.TEXT_FROM_MAIN);
        txtFromMain.setText(str);
        Elev e = (Elev)theIntent.getSerializableExtra("Elev");
//        txtFromMain.setText(e.name);
    }

    @Override
    public void onClick(View v)
    {
        String  str = txtToMain.getText().toString();
        theIntent.putExtra(TEXT_TO_MAIN, str);
        setResult(SecondActivity.RESULT_OK, theIntent);
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}