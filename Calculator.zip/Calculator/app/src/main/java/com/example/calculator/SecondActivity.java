package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnZero, btnOne, btnTwo, btnThree, btnFour, btnFive, btnSix, btnSeven, btnEight,
            btnNine, btnAdd, btnSubtract, btnMultiply, btnDivide, btnProcent, btnEqual, btnCE, btnC;
    Intent theIntent;
    TextView txtTypeField;

    String calc = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        btnZero = findViewById(R.id.btnZero);
        btnOne =  findViewById(R.id.btnOne);
        btnTwo = findViewById(R.id.btnTwo);
        btnThree = findViewById(R.id.btnThree);
        btnFour = findViewById(R.id.btnFour);
        btnFive = findViewById(R.id.btnFive);
        btnSix = findViewById(R.id.btnSix);
        btnSeven = findViewById(R.id.btnSeven);
        btnEight = findViewById(R.id.btnEight);
        btnNine = findViewById(R.id.btnNine);
        btnAdd = findViewById(R.id.btnAdd);
        btnSubtract = findViewById(R.id.btnSubtract);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnDivide = findViewById(R.id.btnDivide);
        btnProcent = findViewById(R.id.btnProcent);
        btnEqual = findViewById(R.id.btnEqual);
        btnCE = findViewById(R.id.btnCE);
        btnC = findViewById(R.id.btnC);
        txtTypeField = findViewById(R.id.txtTypeField);

        btnZero.setOnClickListener(this);
        btnOne.setOnClickListener(this);
        btnTwo.setOnClickListener(this);
        btnThree.setOnClickListener(this);
        btnFour.setOnClickListener(this);
        btnFive.setOnClickListener(this);
        btnSix.setOnClickListener(this);
        btnSeven.setOnClickListener(this);
        btnEight.setOnClickListener(this);
        btnNine.setOnClickListener(this);
        btnAdd.setOnClickListener(this);
        btnSubtract.setOnClickListener(this);
        btnMultiply.setOnClickListener(this);
        btnDivide.setOnClickListener(this);
        btnProcent.setOnClickListener(this);
        btnCE.setOnClickListener(this);
        btnC.setOnClickListener(this);
        btnEqual.setOnClickListener(this);

        theIntent = getIntent();
        String intentStr = theIntent.getStringExtra()
    }

    @Override
    public void onClick(View v) {
        String imput = txtTypeField.getText().toString();
        switch (v.getId())
        {
            case R.id.btnZero:
                imput = imput + "0 ";
                break;
            case R.id.btnOne:
                imput = imput + "1 ";
                break;
            case R.id.btnTwo:
                imput = imput + "2 ";
                break;
            case R.id.btnThree:
                imput = imput + "3 ";
                break;
            case R.id.btnFour:
                imput = imput + "4 ";
                break;
            case R.id.btnFive:
                imput = imput + "5 ";
                break;
            case R.id.btnSix:
                imput = imput + "6 ";
                break;
            case R.id.btnSeven:
                imput = imput + "7 ";
                break;
            case R.id.btnEight:
                imput = imput + "8 ";
                break;
            case R.id.btnNine:
                imput = imput + "9 ";
                break;
            case R.id.btnAdd:
                imput = imput + "+ ";
                break;
            case R.id.btnSubtract:
                imput = imput + "- ";
                break;
            case R.id.btnMultiply:
                imput = imput + "* ";
                break;
            case R.id.btnDivide:
                imput = imput + "/ ";
                break;
            case R.id.btnProcent:
                imput = imput + "% ";
                break;
            case R.id.btnCE:
                imput = "";
                break;
            case R.id.btnC:
                imput = "";
                break;
            case R.id.btnEqual:

                break;
        }
    }
}