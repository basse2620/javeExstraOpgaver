package com.example.appiiappwebapi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.appiiappwebapi.interfaces.IHairCorlorService;
import com.example.appiiappwebapi.interfaces.IPersonService;
import com.example.appiiappwebapi.interfaces.IProgramingLanguage;
import com.example.appiiappwebapi.modles.HairCorlor;
import com.example.appiiappwebapi.modles.Person;
import com.example.appiiappwebapi.modles.ProgramingLanguage;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreateActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener, RadioGroup.OnCheckedChangeListener, CompoundButton.OnCheckedChangeListener {


    ArrayList<HairCorlor> hairCorlors;
    ArrayList<String> color = new ArrayList<>();
    Person person = new Person();

    Button btnCancel, btnDelete, btnCreate;
    EditText txtAddress, txtName, txtNote, txtPhone;
    CheckBox chbFavorite;
    RadioGroup rdgProgram;
    Spinner spnHairColor;

    Intent theIntent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        btnCancel = findViewById(R.id.btnCancel);
        btnDelete = findViewById(R.id.btnDelete);
        btnCreate = findViewById(R.id.btnCreate);
        chbFavorite = findViewById(R.id.chbFavorite);
        rdgProgram = findViewById(R.id.rdgProgram);
        spnHairColor = findViewById(R.id.spnHairColor);
        txtAddress = findViewById(R.id.txtAddress);
        txtName = findViewById(R.id.txtName);
        txtNote = findViewById(R.id.txtNote);
        txtPhone = findViewById(R.id.txtPhone);

        btnCancel.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btnCreate.setOnClickListener(this);
        chbFavorite.setOnCheckedChangeListener(this);
        rdgProgram.setOnCheckedChangeListener(this);
        spnHairColor.setOnItemSelectedListener(this);



        setTheIntent();
    }

    private void setTheIntent() {
        theIntent = getIntent();

        IHairCorlorService service = ServiceBuilder.bulderService(IHairCorlorService.class);
        Call<List<HairCorlor>> hairCorlorCall = service.getHairColor();
        hairCorlorCall.enqueue(new Callback<List<HairCorlor>>() {
            @Override
            public void onResponse(Call<List<HairCorlor>> call, Response<List<HairCorlor>> response) {
                hairCorlors = (ArrayList<HairCorlor>) response.body();
                for (HairCorlor hairCorlor : hairCorlors)
                {
                    color.add(hairCorlor.getName());
                }
                ArrayAdapter adapter = new ArrayAdapter<>(CreateActivity.this,
                        android.R.layout.simple_list_item_1,
                        color);
                spnHairColor.setAdapter(adapter);
            }
            @Override
            public void onFailure(Call<List<HairCorlor>> call, Throwable t) {
                Log.d("debug", "t");
            }
        });

    }

    @Override
    public void onClick(View v) {
        if (v == btnCancel)
        {
            theIntent.putExtra("type", "Canceled");
            setResult(EditActivity.RESULT_OK, theIntent);
            finish();
        }
        else if (v == btnDelete)
        {
            txtName.setText("");
            txtPhone.setText("");
            txtAddress.setText("");
            txtNote.setText("");
            chbFavorite.setActivated(false);
            spnHairColor.setSelection(1);
            rdgProgram.clearCheck();
        }
        else if (v == btnCreate)
        {
            person.setName(txtName.getText().toString());
            person.setPhone(Integer.parseInt(txtPhone.getText().toString()));
            person.setAddress(txtAddress.getText().toString());
            person.setNote(txtNote.getText().toString());

            IPersonService service = ServiceBuilder.bulderService(IPersonService.class);
            Call<Integer> createCall = service.createPerson(person);
            createCall.enqueue(new Callback<Integer>() {
                @Override
                public void onResponse(Call<Integer> call, Response<Integer> response) {
                }

                @Override
                public void onFailure(Call<Integer> call, Throwable t) {
                    theIntent.putExtra("type", "Failed to create person");
                    Log.d("debug", "t");
                }
            });
            theIntent.putExtra("type", "Person Created");
            setResult(EditActivity.RESULT_OK, theIntent);
            finish();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        int i = 0;
        for (HairCorlor color : hairCorlors)
        {
            if (position == i)
            {
                person.setHairId(color.getHairId());
            }
            i++;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId)
        {
            case R.id.rdbJava:
                person.setProgramingId(1);
                break;
            case R.id.rdbC:
                person.setProgramingId(2);
                break;
            case R.id.rdbPython:
                person.setProgramingId(3);
                break;
            case R.id.rdbJScipt:
                person.setProgramingId(4);
                break;
            case R.id.rdbFlutter:
                person.setProgramingId(5);
                break;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        person.setFavorite(isChecked);
    }
}