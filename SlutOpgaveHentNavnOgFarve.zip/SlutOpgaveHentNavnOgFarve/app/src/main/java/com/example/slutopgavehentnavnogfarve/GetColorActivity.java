package com.example.slutopgavehentnavnogfarve;

        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.graphics.Color;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.View;
        import android.widget.AdapterView;
        import android.widget.ArrayAdapter;
        import android.widget.Button;
        import android.widget.Spinner;
        import android.widget.TextView;

public class GetColorActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    Button sendColorButton;
    Spinner blueSpinner, greenSpinner, redSpinner;
    TextView colorPrev, titleTxt;

    Intent theIntent;

    String[] colorArray = {"00", "10", "20", "30", "40", "50", "60", "70", "80", "90",
            "A0", "B0", "C0", "D0", "F0", "FF"},
            setColors = {"00", "00", "00"};
    String colorStr = "#000000";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_color);

        sendColorButton = findViewById(R.id.sendColorBtn);
        blueSpinner = findViewById(R.id.blueSpinner);
        greenSpinner = findViewById(R.id.greenSpinner);
        redSpinner = findViewById(R.id.redSpinner);
        colorPrev = findViewById(R.id.colorPrev);
        titleTxt = findViewById(R.id.titleTxt);

        sendColorButton.setOnClickListener(this);

        ArrayAdapter adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,
                colorArray);

        blueSpinner.setAdapter(adapter);
        greenSpinner.setAdapter(adapter);
        redSpinner.setAdapter(adapter);

        blueSpinner.setOnItemSelectedListener(this);
        greenSpinner.setOnItemSelectedListener(this);
        redSpinner.setOnItemSelectedListener(this);

        setTheIntent();
    }

    public void setTheIntent() {
        theIntent = getIntent();
        String typeStr = theIntent.getStringExtra("typeStr"),
                nameStr = theIntent.getStringExtra("nameStr");
        colorStr = theIntent.getStringExtra("colorStr");
        setColors = theIntent.getStringArrayExtra("setColors");
        spinnerSetter(setColors);
        if (!typeStr.equals("") && !nameStr.equals(""))
        {
            titleTxt.setText(typeStr +" " + nameStr + "'s Color");
        }
    }

    public void spinnerSetter(String[] setColors) {
        int i = 0;
        for (String str : colorArray)
        {
            if (setColors[0].equals(str))
            {
                redSpinner.setSelection(i);
            }
            if (setColors[1].equals(str))
            {
                greenSpinner.setSelection(i);
            }
            if (setColors[2].equals(str))
            {
                blueSpinner.setSelection(i);
            }
            i++;
        }
    }

    @Override
    public void onClick(View v) {
        theIntent.putExtra("colorStr", colorStr);
        theIntent.putExtra("setColors", setColors);
        setResult(GetColorActivity.RESULT_OK, theIntent);
        finish();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Log.v("parent", String.valueOf(parent.getSelectedItem()));
        if (parent == redSpinner)
        {
            setColors[0] = String.valueOf(parent.getSelectedItem());
        }
        else if (parent == greenSpinner)
        {
            setColors[1] = String.valueOf(parent.getSelectedItem());
        }
        else if (parent == blueSpinner)
        {
            setColors[2] = String.valueOf(parent.getSelectedItem());
        }
        colorStr = "#" + setColors[0] + setColors[1] +setColors[2];
        colorPrev.setBackgroundColor(Color.parseColor(colorStr));
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        return;
    }
}