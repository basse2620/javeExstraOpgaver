package com.example.appiiappwebapi.modles;

public class HairCorlor {
    int hairId;
    String name;

    public HairCorlor(int hairId, String name) {
        super();
        this.hairId = hairId;
        this.name = name;
    }

    public HairCorlor() {}

    public int getHairId() {
        return hairId;
    }

    public void setHairId(int hairId) {
        this.hairId = hairId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
