package com.example.fingertouch;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.NonNull;

public class MyGraphics extends View implements View.OnTouchListener
{
    int cx = 200, cy = 100;
    int prevX, prevY;
    boolean moving = false;
    int radius = 100;
    Context context;
    public MyGraphics(Context context)
    {
        super(context);
        this.context = context;
        this.setOnTouchListener(this);
    }

    @Override
    public void draw(@NonNull Canvas canvas) {
        super.draw(canvas);

        Paint paint = new Paint();
        paint.setColor(0xFFFF00FF);
        canvas.drawCircle(cx,cy,radius, paint);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event)
    {
        int newX = (int)event.getX();
        int newY = (int)event.getY();
        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                double z = Math.sqrt(Math.pow(newX - cx, 2) + Math.pow(newY - cy, 2));

                if (z <= radius)
                {
                    moving = true;
                    prevX = newX;
                    prevY = newY;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (moving)
                {
                    cx += newX - prevX;
                    cy += newY - prevY;
                    prevX = newX;
                    prevY = newY;

                    invalidate();
                }
                break;
            case MotionEvent.ACTION_UP:
                moving = false;
                break;
        }
        return true;
    }
}
