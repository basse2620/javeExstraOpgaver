package com.example.appiiappwebapi;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;

import com.example.appiiappwebapi.interfaces.IPersonService;
import com.example.appiiappwebapi.modles.Person;
import com.google.android.material.snackbar.Snackbar;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {
    int position;
    String type;
    PersonAdapter personAdapter;
    ArrayList<Person> personList;
    ListView lstPersons;
    ImageButton imgBtnCreate;
    Intent theIntent;

    ActivityResultLauncher<Intent> CreateActivityLauncher;
    ActivityResultLauncher<Intent> EditActivityLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getPersons();

        imgBtnCreate = findViewById(R.id.imgBtnCreate);
        imgBtnCreate.setBackgroundResource(R.drawable.person);
        imgBtnCreate.setOnClickListener(this);
        lstPersons = findViewById(R.id.lstPersons);
        lstPersons.setOnItemClickListener(this);

        CreateActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        Intent intent = result.getData();
                        type = theIntent.getStringExtra("type");
                        snBar(type);
                        getPersons();
                    }
                }
        );

        EditActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        Intent intent = result.getData();
                        type = intent.getStringExtra("type");
                        position = intent.getIntExtra("position", 0);
                        Person person = (Person) intent.getSerializableExtra("person");
                        switch (type)
                        {
                            case "Person Updated":
                                personList.get(position).setName(person.getName());
                                personList.get(position).setPhone(person.getPhone());
                                personList.get(position).setAddress(person.getAddress());
                                personList.get(position).setNote(person.getNote());
                                personList.get(position).setFavorite(person.getFavorite());
                                personList.get(position).setHairId(person.getHairId());
                                personList.get(position).setProgramingId(person.getProgramingId());
                                break;
                            case "Person Deleted":
                                personList.remove(position);
                                break;
                        }
                        snBar(type);
                    }
                }
        );
    }

    public void getPersons()
    {
        IPersonService iPersonService = ServiceBuilder.bulderService(IPersonService.class);
        Call<List<Person>> lPRequest = iPersonService.getPersons();
        lPRequest.enqueue(new Callback<List<Person>>() {
            @Override
            public void onResponse(Call<List<Person>> call, Response<List<Person>> response) {
                Log.v("name", "1");
                if (response.isSuccessful())
                {
                    personList = (ArrayList<Person>) response.body();
                    personAdapter = new PersonAdapter(MainActivity.this, personList);
                    personAdapter.notifyDataSetChanged();

                    lstPersons = findViewById(R.id.lstPersons);
                    lstPersons.setAdapter(personAdapter);
                }
            }
            @Override
            public void onFailure(Call<List<Person>> call, Throwable t) {
                Log.d("debug", t.toString());
            }
        });
    }

    public void snBar(String str)
    {
        Snackbar snack = Snackbar.make(
                imgBtnCreate,
                "" + type,
                Snackbar.LENGTH_LONG);
        snack.show();
    }

    @Override
    public void onClick(View v) {
        theIntent = new Intent(this, CreateActivity.class);
        CreateActivityLauncher.launch(theIntent);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        theIntent = new Intent(this, EditActivity.class);

        Person person = personList.get(position);
        theIntent.putExtra("position", position);
        theIntent.putExtra("person", person);
        EditActivityLauncher.launch(theIntent);
    }
}