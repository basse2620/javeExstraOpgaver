package com.example.multiplecalculators;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

public class SecondCalculatorActivity extends AppCompatActivity implements View.OnClickListener, RadioGroup.OnCheckedChangeListener {

    Button calcBtn, returnBtn;
    EditText firstNumberTxt, secondNumberTxt;
    RadioGroup calcRdg;
    Spinner calcTypeSpinner;
    TextView resultTxt;
    Intent theIntent;

    String[] calcTypes = {"Add", "Subtract", "Multiply", "Divide"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_calculator);

        firstNumberTxt = findViewById(R.id.firstNumberTxt);
        secondNumberTxt = findViewById(R.id.secondNumberTxt);
        calcBtn = findViewById(R.id.calcBtn);
        returnBtn = findViewById(R.id.returnBtn);
        calcTypeSpinner = findViewById(R.id.caclTypeSpinner);
        resultTxt = findViewById(R.id.resultTxt);
        calcRdg = findViewById(R.id.calcRdg);

        ArrayAdapter adapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_item,
                calcTypes);

        calcTypeSpinner.setAdapter(adapter);

        calcBtn.setOnClickListener(this);
        returnBtn.setOnClickListener(this);
        calcRdg.setOnCheckedChangeListener(this);
        switchCalc();
    }

    public void switchCalc() {
        theIntent = getIntent();
        String result;
        String intentStr = theIntent.getStringExtra("resultToSecond");
        if (intentStr != "") {
            String[] strArray = intentStr.split("\\s");
            if (strArray.length == 1) {
                firstNumberTxt.setText(strArray[0]);
            } else if (strArray.length >= 3) {
                double firstNumber = Double.parseDouble(strArray[0]),
                        secondNumber = Double.parseDouble(strArray[2]);
                firstNumberTxt.setText(strArray[0]);
                secondNumberTxt.setText(strArray[2]);
                switch (strArray[1]) {
                    case "+":
                        resultTxt.setText(String.valueOf(firstNumber + secondNumber));
                        break;
                    case "-":
                        resultTxt.setText(String.valueOf(firstNumber - secondNumber));
                        break;
                    case "*":
                        resultTxt.setText(String.valueOf(firstNumber * secondNumber));
                        break;
                    case "/":
                        resultTxt.setText(String.valueOf(firstNumber / secondNumber));
                        break;
                    case "%":
                        resultTxt.setText(String.valueOf(firstNumber / 100 * secondNumber));
                        break;
                }
            }
        }
    }
    @Override
    public void onClick(View v) {
        String firstNumberStr = firstNumberTxt.getText().toString(),
                secondNumberStr = secondNumberTxt.getText().toString(),
                resultStr = resultTxt.getText().toString();
        if (v == calcBtn)
        {
            Double firstNumber = Double.parseDouble(firstNumberStr);
            Double secondNumber = Double.parseDouble(secondNumberStr);
            String selectedOperator = calcTypeSpinner.getSelectedItem().toString();
        switch (selectedOperator) {
            case "Add":
                resultTxt.setText(String.valueOf(firstNumber + secondNumber));
                break;
            case "Subtract":
                resultTxt.setText(String.valueOf(firstNumber - secondNumber));
                break;
            case "Multiply":
                resultTxt.setText(String.valueOf(firstNumber * secondNumber));
                break;
            case "Divide":
                if (secondNumber != 0)
                {
                    resultTxt.setText(String.valueOf(firstNumber / secondNumber));
                } else {
                    resultTxt.setText("Cannot divide by zero.");
                    return;
                }
                break;
            }
        }
        else if (v == returnBtn)
        {
            theIntent.putExtra("resultFromSecondCalc", resultStr);
            setResult(SecondCalculatorActivity.RESULT_OK, theIntent);
            finish();
        }
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        String firstNumberStr = firstNumberTxt.getText().toString(),
                secondNumberStr = secondNumberTxt.getText().toString();
        Double firstNumber = Double.parseDouble(firstNumberStr);
        Double secondNumber = Double.parseDouble(secondNumberStr);
        switch (checkedId) {
            case 1:
                resultTxt.setText(String.valueOf(firstNumber + secondNumber));
                break;
            case 2:
                resultTxt.setText(String.valueOf(firstNumber - secondNumber));
                break;
            case 3:
                resultTxt.setText(String.valueOf(firstNumber * secondNumber));
                break;
            case 4:
                resultTxt.setText(String.valueOf(firstNumber / secondNumber));
                break;
        }
    }
}